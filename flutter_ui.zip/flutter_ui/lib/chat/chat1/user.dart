class User{
  String name , avatar, phone;

  User({this.name, this.avatar, this.phone});

}