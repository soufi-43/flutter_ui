import 'package:flutterui/chat/chat1/user.dart';
import 'package:flutterui/chat/chat1/message.dart';


class Conversation {

  List<User> users ;
  List<Message> messages ;

  Conversation({this.users, this.messages});


}